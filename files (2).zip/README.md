# Automation Demo — Plug & Play Deployment

This repository is a complete, copy-paste template that enables automatic deployment to a server on push to `main`. Follow these exact steps — no other explanation required.

## What this contains
- GitHub Pages workflow (existing): `.github/workflows/deploy.yml`
- SSH deploy workflow (new): `.github/workflows/ssh-deploy.yml`
- Server helper script: `scripts/deploy.sh`
- Example systemd unit: `deploy/myapp.service`
- Example Docker Compose: `deploy/docker-compose.yml.example`

## Required repository secrets (add these exactly as named)
- SSH_PRIVATE_KEY  — the private key content (generated locally)
- DEPLOY_HOST      — server IP or hostname (e.g., 203.0.113.10)
- DEPLOY_USER      — username (recommended: `deploy`)
- DEPLOY_PATH      — target path on server (e.g., `/var/www/myapp`)
- DEPLOY_PORT      — optional SSH port (default 22)

Add via: Repository → Settings → Secrets and variables → Actions → New repository secret

## One-shot server setup (run these commands on the server as root or via sudo)
Replace placeholders (203.0.113.10, /path/to/automation_deploy_key.pub, /var/www/myapp) as needed.

1) Generate keypair (on admin workstation)
```bash
ssh-keygen -t ed25519 -C "github-actions-deploy" -f ./automation_deploy_key -N ""
# Keep automation_deploy_key private; copy automation_deploy_key.pub to server