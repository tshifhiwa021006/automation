#!/usr/bin/env bash
set -euo pipefail

# scripts/deploy.sh
# Runs on the server inside DEPLOY_PATH.
# Writes a detailed deploy log to /var/log/automation-deploy.log

LOGFILE="/var/log/automation-deploy.log"
mkdir -p "$(dirname "$LOGFILE")"
exec >>"$LOGFILE" 2>&1

echo "----- Deploy started at $(date -u +'%Y-%m-%dT%H:%M:%SZ') -----"

# 1) If run as root, set ownership to deploy if user exists.
if [ "$(id -u)" -eq 0 ]; then
  if id deploy >/dev/null 2>&1; then
    chown -R deploy:deploy .
    echo "Ownership set to deploy:deploy"
  fi
fi

# 2) Docker Compose branch
if [ -f docker-compose.yml ] || [ -f docker-compose.yaml ]; then
  echo "Detected docker-compose file. Using docker compose to pull & up."
  if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
    docker compose pull || true
    docker compose up -d --remove-orphans
    echo "Docker compose up complete"
    exit 0
  elif command -v docker-compose >/dev/null 2>&1; then
    docker-compose pull || true
    docker-compose up -d --remove-orphans
    echo "docker-compose up complete"
    exit 0
  else
    echo "ERROR: docker compose not installed."
    exit 1
  fi
fi

# 3) Node.js branch
if [ -f package.json ]; then
  echo "Detected Node.js app"
  if command -v npm >/dev/null 2>&1; then
    echo "Installing npm dependencies (npm ci)"
    npm ci --silent
    echo "Running build (if present)"
    npm run build --if-present || true
  elif command -v yarn >/dev/null 2>&1; then
    echo "Installing yarn dependencies"
    yarn install --frozen-lockfile --silent
    yarn build --silent || true
  else
    echo "WARNING: Node.js not installed"
  fi

  # Restart systemd service if configured (myapp.service)
  if systemctl list-units --full -all | grep -q "myapp.service"; then
    echo "Restarting myapp.service"
    sudo systemctl restart myapp.service || true
  fi

  echo "Node deploy finished"
  exit 0
fi

# 4) Static site fallback
echo "No Docker/Node detected. Treating as static site."
if [ -n "${DEPLOY_TARGET_WEBROOT:-}" ]; then
  echo "Syncing to webroot: ${DEPLOY_TARGET_WEBROOT}"
  rsync -az --delete --exclude '.git' ./ "${DEPLOY_TARGET_WEBROOT}/"
  echo "Static site sync complete"
fi

echo "Deploy finished at $(date -u +'%Y-%m-%dT%H:%M:%SZ')"